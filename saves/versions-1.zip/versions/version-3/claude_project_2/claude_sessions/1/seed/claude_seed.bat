cabal v2-run seed
