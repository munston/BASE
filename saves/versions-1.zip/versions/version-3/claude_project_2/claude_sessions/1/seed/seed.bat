cabal v2-repl seed
pause
seed
