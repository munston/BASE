module Seed
  ( main
  ) where

main :: IO ()
main = writeFile "seed.out" "seed loaded\n"
