module Main where

import Seed (main)

main :: IO ()
main = Seed.main
