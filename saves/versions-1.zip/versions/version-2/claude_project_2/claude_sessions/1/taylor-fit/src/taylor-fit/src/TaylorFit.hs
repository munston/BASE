module TaylorFit
  ( main
  ) where

main :: IO ()
main = writeFile "taylor-fit.out" "taylor-fit loaded\n"
