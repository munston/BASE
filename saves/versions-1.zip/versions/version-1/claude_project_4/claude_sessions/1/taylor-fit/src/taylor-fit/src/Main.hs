module Main where

import TaylorFit (main)

main :: IO ()
main = TaylorFit.main
