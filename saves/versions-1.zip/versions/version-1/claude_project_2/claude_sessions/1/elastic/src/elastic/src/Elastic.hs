module Elastic
  ( main
  ) where

main :: IO ()
main = putStrLn "elastic loaded"
