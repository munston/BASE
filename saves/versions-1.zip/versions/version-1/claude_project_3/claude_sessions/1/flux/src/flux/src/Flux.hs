module Flux
  ( main
  ) where

main :: IO ()
main = putStrLn "flux loaded"
