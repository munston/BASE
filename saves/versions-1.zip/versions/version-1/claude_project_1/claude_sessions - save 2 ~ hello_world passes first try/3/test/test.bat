cabal v2-repl test
