cabal v2-repl guy
pause
guy
