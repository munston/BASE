module Test
  ( main
  ) where

main :: IO ()
main = putStrLn "hello world"
